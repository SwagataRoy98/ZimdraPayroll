from django.contrib import admin
from .models import DesignationMaster, DepartmentMaster, Attendence, EmpMaster, EmpSalary, \
    EmpSpecialAllowanceDeduction, EmployeeTransaction, TaxMaster, LeaveMaster, LoanMaster, \
    LoanTransaction, DataChecking, AuthModel

admin.site.register(DepartmentMaster)
admin.site.register(DesignationMaster)
admin.site.register(Attendence)
admin.site.register(EmpMaster)
admin.site.register(EmpSalary)
admin.site.register(EmployeeTransaction)
admin.site.register(EmpSpecialAllowanceDeduction)
admin.site.register(TaxMaster)
admin.site.register(LeaveMaster)
admin.site.register(LoanMaster)
admin.site.register(LoanTransaction)
admin.site.register(DataChecking)
admin.site.register(AuthModel)
# Register your models here.
