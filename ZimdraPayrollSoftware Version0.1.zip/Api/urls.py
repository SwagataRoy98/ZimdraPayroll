from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView

from .views import department_view, designation_view, employee_view, employee_detail_view, employee_filter_view, \
    tax_view, emp_sa_view, emp_sa_det_view, tax_detail_view, emp_insert_view, post_salary, employee_by_dept_desg, \
    attendance_View, attendence_specific_month, ad_View, ad_specific_month, loan_module, emp_trans_view, \
    validate_salary, letter_settlement, MyTokenObtainPairView, register_view, change_view
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('ad/', ad_View, name='ad_url'),
    path('ad_spec/', ad_specific_month, name='att_url'),
    path('att/', attendance_View, name='att_url'),
    path('attspec/', attendence_specific_month, name='att_spec_url'),
    path('department/', department_view, name='department_url'),
    path('designation/', designation_view, name='designation_url'),
    path('emp/', employee_view, name='employee_url'),
    path('emp/<str:emp_code>', employee_detail_view, name='emp_detail_url'),
    path(f"emp/filter/", employee_filter_view, name='emp_filter_url'),
    path(f"emp/filter/<str:pk>", emp_insert_view, name='emp_update_url'),
    path('tax/', tax_view, name='tax_url'),
    path('tax/<str:pk>', tax_detail_view, name='sad_det_url'),
    path('sad/', emp_sa_view, name='sad_url'),
    path('sad/<str:pk>', emp_sa_det_view, name='sad_det_url'),
    path('post/', post_salary, name ='post_url'),
    path('xxx/', employee_by_dept_desg, name='xxx'),
    path('loan/', loan_module, name='xxx'),
    path('post/validate', validate_salary, name='xxx'),
    path('rep/trans/', emp_trans_view, name='trans_url'),
    path('rep/settlement/<str:pk>', letter_settlement, name='settle_url'),
    path('token/', MyTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('register/', register_view, name='register'),
    path('change/<int:pk>', change_view, name='register')

    ### Frontend urls
    ]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
