from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from django.db import connection as cnx
from django.shortcuts import render
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework_simplejwt.authentication import JWTAuthentication
from django.views.decorators.clickjacking import xframe_options_exempt
# Create your views here.
from .models import DepartmentMaster, DesignationMaster, EmpMaster, TaxMaster, EmpSpecialAllowanceDeduction, EmpSalary, \
    Attendence
from .serializers import DepartmentMasterSerializer, DesignationMasterSerializer, EmployeeMasterSerializer, \
    DepartmentCustomSerializer, DesignationCustomSerializer, TaxMasterSerializer, EmpSADSerializer, \
    EmployeeCustomerSerializer, AttendanceSerializer, RegisterSerializer, ChangeSerializer
from django.contrib.auth import authenticate

from django.contrib.auth.password_validation import MinimumLengthValidator, \
    UserAttributeSimilarityValidator, CommonPasswordValidator, NumericPasswordValidator
from django.core.exceptions import ValidationError
from django.contrib.auth.models import User
import random

def dictfetchall(cursor):
    "Return all rows from a cursor as a dict"
    columns = [col[0] for col in cursor.description]
    data = [
        dict(zip(columns, row))
        for row in cursor.fetchall()
    ]
    return data


class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        # Add custom claims
        token['username'] = user.username
        return token


class MyTokenObtainPairView(TokenObtainPairView):
    serializer_class = MyTokenObtainPairSerializer


@api_view(['GET', 'POST'])
# @permission_classes([IsAuthenticated])
def attendance_View(request):
    if request.method == 'GET':
        return Response(data=dictfetchall(cnx.cursor().execute(f"SELECT distinct EM.Emp_Code, EM.Emp_Name,EM.Department_Code,EM.Designation_Code"\
                                    " FROM [db_accessadmin].[Emp_Master] EM where EM.Active_Flag ='Y'")))
    elif request.method == 'POST':
        with cnx.cursor() as cursor:
            data = dictfetchall(
                cnx.cursor().execute(f"SELECT count(*) as counter from [Data_Checking] where [Year] = '{request.data['Year']}' and [month] = '{request.data['Month']}'"))
            if data[0]['counter'] == 0:
                cursor.execute('INSERT INTO [Data_Checking] ([Year], [Month], [Attendance], [Insert_TS], [Update_TS]) '
                           f"VALUES ('{request.data['Year']}','{request.data['Month']}','{request.data['Attendance']}', getdate(), getdate())")
            else:
                cursor.execute(f"UPDATE [Data_Checking] SET [Attendance] =  '{request.data['Attendance']}', [Update_TS] = getdate() "
                               f"WHERE [YEAR] = '{request.data['Year']}' and [Month] = '{request.data['Month']}' ")
            cnx.commit()
        return Response(status=status.HTTP_200_OK)
    return Response(status=status.HTTP_501_NOT_IMPLEMENTED)


@api_view(['GET','POST','PUT'])
# @permission_classes([IsAuthenticated])
def attendence_specific_month(request):
    flag = False
    if request.method == 'POST':
        res = dictfetchall(cnx.cursor().execute(f"select * from Data_Checking where Year = '{request.data['Cal_Year']}' "
                                                f"and Month='{request.data['Cal_Month']}'"))
        if res is None or len(res) == 0:
            flag = True
        if not flag:
            if res[0]['Attendance'] != 'Y':
                with cnx.cursor() as cursor:
                    res = dictfetchall(
                        cursor.execute(f"select * from [Attendence] where Emp_Code = '{request.data['Emp_Code']}' and Cal_Year = '{request.data['Cal_Year']}' "
                                       f"and Cal_Month='{request.data['Cal_Month']}'"))
                    print(res)
                    if len(res) == 0:
                        cursor.execute(f"INSERT INTO [Attendence] ([Emp_Code], [Cal_Month], [Cal_Year], [Total_Month_Day],[Total_Working_Day],"
                                       f" [Avail_PL], [Avail_CL], [Avail_SL], [Avail_LWOP], [Avail_ML], [Avail_EL], [Avail_BL], [Total_Avail_Leave],"
                                       f"[Overtime], [Insert_TS], [Update_TS]) "
                                       f"VALUES ('{request.data['Emp_Code']}', '{request.data['Cal_Month']}', '{request.data['Cal_Year']}', '{request.data['Total_Month_Day']}'"
                                       f", '{request.data['Total_Working_Day']}', '{request.data['Avail_PL']}', '{request.data['Avail_CL']}',  '{request.data['Avail_SL']}', '{request.data['Avail_LWOP']}',"
                                       f"'{request.data['Avail_ML']}', '{request.data['Avail_EL']}', '{request.data['Avail_BL']}',"
                                       f" '{float(request.data['Avail_PL'])+ float(request.data['Avail_CL'])+ float(request.data['Avail_LWOP'])+ float(request.data['Avail_ML'])+ float(request.data['Avail_EL'])+ float(request.data['Avail_SL']) + float(request.data['Avail_BL']) }', "
                                       f"'{request.data['Overtime']}', getdate(), getdate())")
                    else:
                        cursor.execute(f"UPDATE [Attendence] SET "
                                       f"[Total_Month_Day] = '{request.data['Total_Month_Day']}'"
                                       f",[Total_Working_Day] = '{request.data['Total_Working_Day']}'"
                                       f",[Avail_PL] = '{request.data['Avail_PL']}'"
                                       f",[Avail_CL] = '{request.data['Avail_CL']}'"
                                       f",[Avail_SL] = '{request.data['Avail_SL']}'"
                                       f",[Avail_LWOP] = '{request.data['Avail_LWOP']}'"
                                       f",[Avail_ML] = '{request.data['Avail_ML']}'"
                                       f",[Avail_EL] = '{request.data['Avail_EL']}'"
                                       f",[Avail_BL] = '{request.data['Avail_BL']}'"
                                       f",[Total_Avail_Leave] = '{float(request.data['Avail_PL'])+ float(request.data['Avail_CL'])+ float(request.data['Avail_SL']) + float(request.data['Avail_LWOP'])+ float(request.data['Avail_ML'])+ float(request.data['Avail_EL'])+ float(request.data['Avail_BL']) }'"
                                       f",[Overtime] = '{request.data['Overtime']}'"
                                       f",[Update_TS] = getdate() "
                                       f"WHERE [Emp_Code] = '{request.data['Emp_Code']}' and [Cal_Month] = '{request.data['Cal_Month']}' and [Cal_Year] = '{request.data['Cal_Year']}'")
                    return Response(status=status.HTTP_200_OK)
            else:
                return Response(data={"Error_Message": f"Attendance Record for month {request.data['Cal_Month']} and year {request.data['Cal_Year']} is locked against updation"}, status=status.HTTP_200_OK)
        else:
            with cnx.cursor() as cursor:
                res = dictfetchall(
                    cursor.execute(
                        f"select * from [Attendence] where Emp_Code = '{request.data['Emp_Code']}' and Cal_Year = '{request.data['Cal_Year']}' "
                        f"and Cal_Month='{request.data['Cal_Month']}'"))
                print(res)
                if len(res) == 0:
                    cursor.execute(
                        f"INSERT INTO [Attendence] ([Emp_Code], [Cal_Month], [Cal_Year], [Total_Month_Day],[Total_Working_Day],"
                        f" [Avail_PL], [Avail_CL], [Avail_SL], [Avail_LWOP], [Avail_ML], [Avail_EL], [Avail_BL], [Total_Avail_Leave], "
                        f"[Overtime], [Insert_TS], [Update_TS])"
                        f"VALUES ('{request.data['Emp_Code']}', '{request.data['Cal_Month']}', '{request.data['Cal_Year']}', '{request.data['Total_Month_Day']}'"
                        f", '{request.data['Total_Working_Day']}', '{request.data['Avail_PL']}', '{request.data['Avail_CL']}', '{request.data['Avail_SL']}', '{request.data['Avail_LWOP']}',"
                        f"'{request.data['Avail_ML']}', '{request.data['Avail_EL']}', '{request.data['Avail_BL']}',"
                        f" '{float(request.data['Avail_PL']) + float(request.data['Avail_CL'])+ float(request.data['Avail_SL']) + float(request.data['Avail_LWOP']) + float(request.data['Avail_ML']) + float(request.data['Avail_EL']) + float(request.data['Avail_BL'])}',"
                        f"'{request.data['Overtime']}', getdate(), getdate())")
                else:
                    cursor.execute(f"UPDATE [Attendence] SET "
                                   f"[Total_Month_Day] = '{request.data['Total_Month_Day']}'"
                                   f",[Total_Working_Day] = '{request.data['Total_Working_Day']}'"
                                   f",[Avail_PL] = '{request.data['Avail_PL']}'"
                                   f",[Avail_CL] = '{request.data['Avail_CL']}'"
                                   f",[Avail_SL] = '{request.data['Avail_SL']}'"
                                   f",[Avail_LWOP] = '{request.data['Avail_LWOP']}'"
                                   f",[Avail_ML] = '{request.data['Avail_ML']}'"
                                   f",[Avail_EL] = '{request.data['Avail_EL']}'"
                                   f",[Avail_BL] = '{request.data['Avail_BL']}'"
                                   f",[Total_Avail_Leave] = '{float(request.data['Avail_PL']) + float(request.data['Avail_CL']) + float(request.data['Avail_LWOP']) + float(request.data['Avail_ML']) + float(request.data['Avail_EL']) + float(request.data['Avail_BL'])}'"
                                   f",[Overtime] = '{request.data['Overtime']}'"
                                   f",[Update_TS] = getdate() "
                                   f"WHERE [Emp_Code] = '{request.data['Emp_Code']}' and [Cal_Month] = '{request.data['Cal_Month']}' and [Cal_Year] = '{request.data['Cal_Year']}'")
                return Response(status=status.HTTP_200_OK)


@api_view(['GET', 'POST'])
# @permission_classes([IsAuthenticated])
def ad_View(request):
    if request.method == 'GET':
        return Response(data=dictfetchall(cnx.cursor().execute(f"SELECT distinct EM.Emp_Code, EM.Emp_Name,EM.Department_Code,EM.Designation_Code"\
                                    " FROM [db_accessadmin].[Emp_Master] EM where EM.Active_Flag ='Y'")))
    elif request.method == 'POST':
        with cnx.cursor() as cursor:
            data = dictfetchall(
                cnx.cursor().execute(f"SELECT count(*) as counter from [Data_Checking] where [Year] = '{request.data['Year']}' and [month] = '{request.data['Month']}'"))
            if data[0]['counter'] == 0:
                cursor.execute('INSERT INTO [Data_Checking] ([Year], [Month], [Emp_SAD], [Insert_TS], [Update_TS]) '
                           f"VALUES ('{request.data['Year']}','{request.data['Month']}','{request.data['Emp_SAD']}', getdate(), getdate())")
            else:
                cursor.execute(f"UPDATE [Data_Checking] SET [Emp_SAD] =  '{request.data['Emp_SAD']}', [Update_TS] = getdate() "
                               f"WHERE [YEAR] = '{request.data['Year']}' and [Month] = '{request.data['Month']}' ")
        return Response(status=status.HTTP_200_OK)
    return Response(status=status.HTTP_501_NOT_IMPLEMENTED)


@api_view(['POST'])
# @permission_classes([IsAuthenticated])
def ad_specific_month(request):
    if request.method == 'POST':
        flag = False
        print(request.data)
        res = dictfetchall(
            cnx.cursor().execute(f"select * from Data_Checking where Year = '{request.data['Cal_Year']}' "
                                 f"and Month='{request.data['Cal_Month']}'"))
        print('checkpoint 01')
        if res is None or len(res) == 0:
            flag = True
        print('checkpoint 01.1')
        if not flag:
            print('checkpoint 01.2')
            if res[0]['Emp_SAD'] != 'Y':
                print('checkpoint 02')
                with cnx.cursor() as cursor:
                    res = dictfetchall(
                        cursor.execute(
                            f"select * from [Emp_Special_Allowance_Deduction] where Emp_Code = '{request.data['Emp_Code']}' and CYear = '{request.data['Cal_Year']}' "
                            f"and CMonth='{request.data['Cal_Month']}'"))
                    if len(res) == 0:
                        print('checkpoint 03')
                        cursor.execute(
                            f"INSERT INTO [Emp_Special_Allowance_Deduction] "
                            f"([Emp_Code],"
                            f"[CMONTH],"
                            f"[CYear],"
                            f"[Conv_Allow],"
                            f"[Vouc_Allow],"
                            f"[Special_Allow],"
                            f"[LE_Allow],"
                            f"[LTC_Allow],"
                            f"[OT_Allow],"
                            f"[Bonus_Allow],"
                            f"[Other_Allow],"
                            f"[Benifit_Allow],"
                            f"[Arr_Allow],"
                            f"[Advance_Ded],"
                            f"[Special_Ded],"
                            f"[Loan_Skip_Flag],"
                            f"[Insert_TS],"
                            f"[Update_TS]) "
                            f"VALUES("
                            f"'{request.data['Emp_Code']}',"
                            f"'{request.data['Cal_Month']}',"
                            f"'{request.data['Cal_Year']}',"
                            f"{request.data['Conv_Allow']},"
                            f"{request.data['Vouc_Allow']},"
                            f"{request.data['Special_Allow']},"
                            f"{request.data['LE_Allow']},"
                            f"{request.data['LTC_Allow']},"
                            f"{request.data['OT_Allow']},"
                            f"{request.data['Bonus_Allow']},"
                            f"{request.data['Other_Allow']},"
                            f"{request.data['Benifit_Allow']},"
                            f"{request.data['Arr_Allow']},"
                            f"{request.data['Advance_Ded']},"
                            f"{request.data['Special_Ded']},"
                            f"'{request.data['Loan_Skip_Flag']}',"
                            f"getdate(),"
                            f"getdate())")
                    else:
                        print('checkpoint 04')
                        cursor.execute(f"UPDATE [Emp_Special_Allowance_Deduction] SET "
                                       f" [Conv_Allow] = '{request.data['Conv_Allow']}'"
                                       f",[Vouc_Allow] = '{request.data['Vouc_Allow']}'"
                                       f",[Special_Allow] = '{request.data['Special_Allow']}'"
                                       f",[LE_Allow] = '{request.data['LE_Allow']}'"
                                       f",[LTC_Allow] = '{request.data['LTC_Allow']}'"
                                       f",[OT_Allow] = '{request.data['OT_Allow']}'"
                                       f",[Bonus_Allow] = '{request.data['Bonus_Allow']}'"
                                       f",[Other_Allow] = '{request.data['Other_Allow']}'"
                                       f",[Benifit_Allow] = '{request.data['Benifit_Allow']}'"
                                       f",[Arr_Allow] = '{request.data['Arr_Allow']}'"
                                       f",[Advance_Ded] = '{request.data['Advance_Ded']}'"
                                       f",[Special_Ded] = '{request.data['Special_Ded']}'"
                                       f",[Loan_Skip_Flag] = '{request.data['Loan_Skip_Flag']}'"
                                       f",[Update_TS] = getdate()"
                                       f"WHERE [Emp_Code] = '{request.data['Emp_Code']}' and [CMonth] = '{request.data['Cal_Month']}' and [CYear] = '{request.data['Cal_Year']}'")
                    return Response(status=status.HTTP_200_OK)
            else:
                print('checkpoint 01.3')
                return Response(data={
                    "Error_Message": f"Attendance Record for month {request.data['Cal_Month']} and year {request.data['Cal_Year']} is locked against updation"},
                                status=status.HTTP_400_BAD_REQUEST)
        else:
            print('checkpoint 05')
            with cnx.cursor() as cursor:
                res = dictfetchall(
                    cursor.execute(
                        f"select * from [Emp_Special_Allowance_Deduction] where Emp_Code = '{request.data['Emp_Code']}' and CYear = '{request.data['Cal_Year']}' "
                        f"and CMonth='{request.data['Cal_Month']}'"))
                if len(res) == 0:
                    print('checkpoint 06')
                    cursor.execute(
                        f"INSERT INTO [Emp_Special_Allowance_Deduction] "
                        f"([Emp_Code],"
                        f"[CMONTH],"
                        f"[CYear],"
                        f"[Conv_Allow],"
                        f"[Vouc_Allow],"
                        f"[Special_Allow],"
                        f"[LE_Allow],"
                        f"[LTC_Allow],"
                        f"[OT_Allow],"
                        f"[Bonus_Allow],"
                        f"[Other_Allow],"
                        f"[Benifit_Allow],"
                        f"[Arr_Allow],"
                        f"[Advance_Ded],"
                        f"[Special_Ded],"
                        f"[Loan_Skip_Flag],"
                        f"[Insert_TS],"
                        f"[Update_TS]) "
                        f"VALUES("
                        f"'{request.data['Emp_Code']}',"
                        f"'{request.data['Cal_Month']}',"
                        f"'{request.data['Cal_Year']}',"
                        f"{request.data['Conv_Allow']},"
                        f"{request.data['Vouc_Allow']},"
                        f"{request.data['Special_Allow']},"
                        f"{request.data['LE_Allow']},"
                        f"{request.data['LTC_Allow']},"
                        f"{request.data['OT_Allow']},"
                        f"{request.data['Bonus_Allow']},"
                        f"{request.data['Other_Allow']},"
                        f"{request.data['Benifit_Allow']},"
                        f"{request.data['Arr_Allow']},"
                        f"{request.data['Advance_Ded']},"
                        f"{request.data['Special_Ded']},"
                        f"'{request.data['Loan_Skip_Flag']}',"
                        f"getdate(),"
                        f"getdate())")
                else:
                    print('checkpoint 07')
                    cursor.execute(f"UPDATE [Emp_Special_Allowance_Deduction] SET "
                                   f"[Conv_Allow] = '{request.data['Conv_Allow']}'"
                                   f",[Vouc_Allow] = '{request.data['Vouc_Allow']}'"
                                   f",[Special_Allow] = '{request.data['Special_Allow']}'"
                                   f",[LE_Allow] = '{request.data['LE_Allow']}'"
                                   f",[LTC_Allow] = '{request.data['LTC_Allow']}'"
                                   f",[OT_Allow] = '{request.data['OT_Allow']}'"
                                   f",[Bonus_Allow] = '{request.data['Bonus_Allow']}'"
                                   f",[Other_Allow] = '{request.data['Other_Allow']}'"
                                   f",[Benifit_Allow] = '{request.data['Benifit_Allow']}'"
                                   f",[Arr_Allow] = '{request.data['Arr_Allow']}'"
                                   f",[Advance_Ded] = '{request.data['Advance_Ded']}'"
                                   f",[Special_Ded] = '{request.data['Special_Ded']}'"
                                   f",[Loan_Skip_Flag] = '{request.data['Loan_Skip_Flag']}'"
                                   f",[Update_TS] = getdate()"
                                   f"WHERE [Emp_Code] = '{request.data['Emp_Code']}' and [CMonth] = '{request.data['Cal_Month']}' and [CYear] = '{request.data['Cal_Year']}'")
                return Response(status=status.HTTP_200_OK)


#[Emp_Code], [Cal_Month], [Cal_Year]
#[Avail_PL][Avail_CL][Avail_SL][Avail_LWOP][Avail_ML][Avail_EL][Avail_BL][Total_Avail_Leave][Overtime][Insert_TS][Update_TS]


@api_view(['GET', 'POST'])
# @permission_classes([IsAuthenticated])
def department_view(request):
    if request.method == 'GET':
        res1 = DepartmentMaster.objects.all()
        serializer = DepartmentCustomSerializer(res1, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    elif request.method == 'POST':
        serializer = DepartmentMasterSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(data=serializer.data, status=status.HTTP_200_OK)
    return Response(data=serializer.data, status=status.HTTP_501_NOT_IMPLEMENTED)



@api_view(['GET', 'POST'])
# @permission_classes([IsAuthenticated])
def designation_view(request):
    if request.method == 'GET':
        res1 = DesignationMaster.objects.all()
        serializer = DesignationCustomSerializer(res1, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    elif request.method == 'POST':
        serializer = DesignationMasterSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(data=serializer.data, status=status.HTTP_200_OK)
    return Response(data=serializer.data, status=status.HTTP_501_NOT_IMPLEMENTED)


@api_view(['GET', 'POST'])
# @permission_classes([IsAuthenticated])
def employee_view(request):
    if request.method == 'GET':
        res = EmpMaster.objects.all()
        serializer = EmployeeMasterSerializer(res, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    elif request.method == 'POST':
        serializer = EmployeeMasterSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(data=serializer.data, status=status.HTTP_200_OK)
    return Response(data=serializer.data, status=status.HTTP_501_NOT_IMPLEMENTED)


@api_view(['GET', 'PUT', 'DELETE'])
# @permission_classes([IsAuthenticated])
def employee_detail_view(request, emp_code):
    try:
        emp = EmpMaster.objects.get(emp_code=emp_code)
    except EmpSalary.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        return Response(data=EmployeeMasterSerializer(emp).data, status=status.HTTP_200_OK)
    elif request.method == 'PUT':
        serializer = EmployeeCustomerSerializer(emp, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
    elif request.method == 'DELETE':
        emp.delete()
    return Response(status=status.HTTP_501_NOT_IMPLEMENTED)


@api_view(['GET', 'Post'])
# @permission_classes([IsAuthenticated])
def employee_filter_view(request):
    if request.method == 'GET':
        res = dictfetchall(cnx.cursor().execute("SELECT EM.*,ES.Basic_Pay,ES.FY_Year,ES.LPA FROM Emp_Master EM LEFT JOIN Emp_Salary ES "
                                                "ON EM.Emp_Code = ES.Emp_Code AND ES.Current_Flag = 'Y'"))
        return Response(data=res, status=status.HTTP_200_OK)
    if request.method == 'POST':
        if EmpMaster.objects.get(pk=request.data['Emp_Code']) is None:
            sql = f"INSERT INTO Emp_Master ([Emp_Code],[Emp_Name],[Mobile_No],[Email_Id],[Emp_Gender],[Address]" \
                  f",[Gov_Id],[Date_Of_Birth],[Date_Of_Join],[Date_Of_Retirement],[Date_Of_Resignation],[TPN_No]" \
                  f",[Account_No],[Pf_No],[Insurance_No],[GIS_Account_No],[Designation_Code],[Department_Code]" \
                  f",[Employee_Type_Flag],[Active_Flag],[Insert_TS],[Update_TS])" \
                  f"VALUES ({request.data['Emp_Code']},{request.data['Emp_Name']}, {request.data['Mobile_No']}, " \
                  f"{request.data['Email_Id']}, {request.data['Emp_Gender']}, {request.data['Address']}, " \
                  f"{request.data['Gov_Id']}, {request.data['Date_Of_Birth']}, {request.data['Date_Of_Join']}" \
                  f"{request.data['Date_Of_Retirement']}, {request.data['Date_Of_Resignation']}, {request.data['TPN_No']}" \
                  f", {request.data['Account_No']}, {request.data['Pf_No']}, {request.data['Insurance_No']}, " \
                  f"{request.data['GIS_Account_No']}, {request.data['Designation_Code']}, {request.data['Department_Code']}," \
                  f"{request.data['Employee_Type_Flag']},{request.data['Active_Flag']}, getdate(), getdate())"
            with cnx.cursor() as cursor:
                cursor.execute(sql)
                cnx.commit()
                if EmpSalary.objects.get(pk=request.data['Emp_Code']) is None:
                    sql = f"INSERT INTO Emp_Salary" \
                          " ([Emp_Code],[Basic_Pay], [Current_Flag],[FY_Year], [LPA])" \
                          f"values ({request.data['Emp_Code']}, {request.data['Basic_Pay']}, 'Y',{request.data['FY_Year']}, {request.data['LPA']})"
                    cursor.execute(sql)
                    cnx.commit()
                else:
                    data = {'fault_text': 'Data already exist'}
                    return Response(data=data, status=status.HTTP_200_OK)
            return Response(status=status.HTTP_200_OK)
        else:
            data = {'fault_text': 'Data already exist'}
            return Response(data=data, status=status.HTTP_200_OK)
    return Response(status= status.HTTP_501_NOT_IMPLEMENTED)

 
@api_view(['GET', 'POST'])
def tax_view(request):
    if request.method == 'GET':
        res = TaxMaster.objects.all()
        serializer = TaxMasterSerializer(res, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    elif request.method == 'POST':
        serializer = TaxMasterSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(data=serializer.data, status=status.HTTP_200_OK)
    return Response(data=serializer.data, status=status.HTTP_501_NOT_IMPLEMENTED)


@api_view(['GET', 'PUT', 'DELETE'])
# @permission_classes([IsAuthenticated])
def tax_detail_view(request, pk):
    try:
        tax = TaxMaster.objects.get(pk=pk)
    except TaxMaster.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)
    if request.method == 'GET':
        res = TaxMaster.objects.get(pk=pk)
        serializer = TaxMasterSerializer(res)
        return Response(serializer.data, status=status.HTTP_200_OK)
    elif request.method == 'PUT':
        serializer = TaxMasterSerializer(tax, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
    elif request.method == 'DELETE':
        tax.delete()
    return Response(status=status.HTTP_501_NOT_IMPLEMENTED)


@api_view(['GET', 'POST'])
# @permission_classes([IsAuthenticated])
def emp_sa_view(request):
    if request.method == 'GET':
        res = EmpSpecialAllowanceDeduction.objects.all()
        serializer = EmpSADSerializer(res, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

    elif request.method == 'POST':
        serializer = EmpSADSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(data=serializer.data, status=status.HTTP_200_OK)
    return Response(data=serializer.data, status=status.HTTP_501_NOT_IMPLEMENTED)


@api_view(['GET', 'PUT', 'DELETE'])
# @permission_classes([IsAuthenticated])
def emp_sa_det_view(request, pk):
    try:
        obj = EmpSpecialAllowanceDeduction.objects.get(pk=pk)
    except EmpSpecialAllowanceDeduction.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        res = EmpSpecialAllowanceDeduction.objects.get(pk=pk)
        serializer = EmpSADSerializer(res)
        return Response(serializer.data, status=status.HTTP_200_OK)
    elif request.method == 'PUT':
        serializer = EmpSADSerializer(obj, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
    elif request.method == 'DELETE':
        obj.delete()
    return Response(status=status.HTTP_501_NOT_IMPLEMENTED)


@api_view(['POST'])
# @permission_classes([IsAuthenticated])
def emp_trans_view(request):
    if request.method == 'POST':
        res = dictfetchall(cnx.cursor().execute(f"SELECT * FROM [Employee_Transaction] where [Year] = "
                                                f"'{request.data['Year']}' and [Month] = '{request.data['Month']}'"))
        return Response(data=res, status=status.HTTP_200_OK)


@api_view(['GET', 'POST'])
# @permission_classes([IsAuthenticated])
def emp_insert_view(request, pk):
    if request.method == 'GET':
        res = dictfetchall(cnx.cursor().execute(
            f"SELECT EM. *, ES.Basic_Pay, ES.FY_Year, ES.LPA FROM [db_accessadmin].[Emp_Master] "
            "EM LEFT JOIN[db_accessadmin].[Emp_Salary] ES ON EM.Emp_Code = ES.Emp_Code AND ES.Current_Flag = 'Y' WHERE "
        f"EM.Emp_Code = '{pk}'"))
        return Response(data=res, status=status.HTTP_200_OK)
    if request.method == 'POST':
        print(request.data)
        with cnx.cursor() as cursor:
            print('Before Emp_Master update')
            sql = f"UPDATE [Emp_Master] " \
                    f"SET " \
                    f"[Emp_Name] = '{request.data['Emp_Name']}', " \
                    f"[Mobile_No] = '{request.data['Mobile_No']}', " \
                    f"[Email_Id] = '{request.data['Email_Id']}', " \
                    f"[Emp_Gender] = '{request.data['Emp_Gender']}', " \
                    f"[Address] = '{request.data['Address']}', " \
                    f"[Gov_Id] = '{request.data['Gov_Id']}', " \
                    f"[Date_Of_Birth] = CAST('{request.data['Date_Of_Birth']}' AS DATE), " \
                    f"[Date_Of_Join] = CAST('{request.data['Date_Of_Join']}' AS DATE), " \
                    f"[Date_Of_Retirement] = CAST('{request.data['Date_Of_Retirement']}' AS DATE), " \
                    f"[Date_Of_Resignation] = CASE WHEN '{request.data['Date_Of_Resignation']}' = '' THEN NULL ELSE CAST('{request.data['Date_Of_Resignation']}' AS DATE) END, " \
                    f"[TPN_No] = '{request.data['TPN_No']}', " \
                    f"[Account_No] = '{request.data['Account_No']}', " \
                    f"[Pf_No] = '{request.data['Pf_No']}', " \
                    f"[Insurance_No] = '{request.data['Insurance_No']}', " \
                    f"[GIS_Account_No] = '{request.data['GIS_Account_No']}', " \
                    f"[Designation_Code] = '{request.data['Designation_Code']}', " \
                    f"[Department_Code] = '{request.data['Department_Code']}', " \
                    f"[Employee_Type_Flag] = '{request.data['Employee_Type_Flag']}', " \
                    f"[Update_TS] = GETDATE() " \
                    f"WHERE [Emp_Code] = '{pk}';"

            cursor.execute(sql)
            print('After update')
            emp_sal = dictfetchall(cursor.execute("SELECT ES.Basic_Pay,ES.FY_Year,ES.LPA "
                                                  f"FROM Emp_Salary ES where ES.Emp_Code = '{pk}' and ES.Current_Flag = "
                                                  f"'Y'"))
            if len(emp_sal) != 0:
                if emp_sal[0]['Basic_Pay'] != request.data['Basic_Pay'] or emp_sal[0]['FY_Year'] != request.data[
                    'FY_Year'] or \
                        emp_sal[0]['LPA'] != request.data['LPA']:
                    print('In Here 3')
                    sql = f"UPDATE Emp_Salary SET [Current_Flag] = 'N', [Update_TS] = getdate()" \
                          f"WHERE [Emp_Code] = '{pk}' and [Current_Flag] = 'Y'"
                    cursor.execute(sql)
                    print('In Here 4')
                    sql = f"INSERT INTO Emp_Salary" \
                          " ([Emp_Code],[Basic_Pay], [FY_Year], [LPA], [Current_Flag], [Insert_TS], [Update_TS])" \
                          f"values ('{request.data['Emp_Code']}', '{request.data['Basic_Pay']}', '{request.data['FY_Year']}'," \
                          f"'{request.data['LPA']}', 'Y', getdate(), getdate())"
                    cursor.execute(sql)
                    cnx.commit()
                    return Response(status=status.HTTP_200_OK)
            else:
                sql = f"INSERT INTO Emp_Salary" \
                      " ([Emp_Code],[Basic_Pay], [FY_Year], [LPA], [Current_Flag], [Insert_TS], [Update_TS])" \
                      f"values ('{request.data['Emp_Code']}', '{request.data['Basic_Pay']}', '{request.data['FY_Year']}'," \
                      f"'{request.data['LPA']}', 'Y', getdate(), getdate())"
                cursor.execute(sql)
                cnx.commit()
                return Response(status=status.HTTP_200_OK)
    return Response(status=status.HTTP_501_NOT_IMPLEMENTED)



@api_view(['POST'])
# @permission_classes([IsAuthenticated])
def post_salary(request):
    if request.method == 'POST':
        print(request.data)
        sql = f"select count(*) as counter from [Emp_Master] where Date_Of_Birth = '1967-09-23' and Emp_Name like 'Bumpa Choden'"
        emp_sal = dictfetchall(cnx.cursor().execute(sql))
        if request.data['Sal_Post'] == 'Y' and emp_sal[0]['counter'] == 0:
            sql_test = f"SELECT MAX(SID) as s_max FROM [Exception_Table]"
            sql = f"BEGIN TRY  exec [db_accessadmin].[sp_insert_update_Emp_Transaction] '{request.data['Month']}', '{request.data['Year']}'  END TRY "\
                  f"BEGIN CATCH " \
                  f"insert into [db_accessadmin].[Exception_Table]" \
                  f"SELECT  ERROR_NUMBER() AS ErrorNumber  " \
                  f",ERROR_SEVERITY() AS ErrorSeverity  " \
                  f",ERROR_STATE() AS ErrorState  " \
                  f",ERROR_PROCEDURE() AS ErrorProcedure  " \
                  f",ERROR_LINE() AS ErrorLine  " \
                  f",ERROR_MESSAGE() AS ErrorMessage" \
                  f",getdate(); " \
                  f"END CATCH;"
            # sql = f"exec [db_accessadmin].[sp_insert_update_Emp_Transaction] '{request.data['Month']}'," \
            #       f"'{request.data['Year']}'"
            print(sql)
            with cnx.cursor() as cursor:
                res_prev = dictfetchall(cursor.execute(sql_test))
                cursor.execute(sql)
                res_after = dictfetchall(cursor.execute(sql_test))
                print(res_prev[0]['s_max'])
                print(res_after[0]['s_max'])
                if int(res_prev[0]['s_max']) < int(res_after[0]['s_max']):
                    sql_1 = f"select ErrorMessage from [db_accessadmin].[Exception_Table] where SID={res_after[0]['s_max']}"
                    err_m = dictfetchall(cursor.execute(sql_1))
                    print(err_m[0]['ErrorMessage'])
                    stat_message = {
                        "Error Message": err_m[0]['ErrorMessage']
                    }
                    return Response(data=stat_message, status=status.HTTP_400_BAD_REQUEST)
                cnx.commit()
            return Response(status=status.HTTP_200_OK)
    return Response(status=status.HTTP_501_NOT_IMPLEMENTED)


@api_view(['POST'])
# @permission_classes([IsAuthenticated])
def validate_salary(request):
    if request.method == 'POST':
        if request.data['validated'] == 'Y':
            sql = f"update [Employee_Transaction] SET Flag = 'Y' where [Year] = '{request.data['Year']}' and " \
                  f"[Month] = '{request.data['Month']}'"
            cnx.cursor().execute(sql)
            dicti = {
                "message": f"Data for month {request.data['Month']} and year {request.data['Year']} is "
                           f"validated and frozen."
            }
            return Response(data=dicti, status=status.HTTP_200_OK)
    else:
        return Response(status=status.HTTP_501_NOT_IMPLEMENTED)

@api_view(['POST'])
# @permission_classes([IsAuthenticated])
def employee_by_dept_desg(request):
    if request.method == 'POST':
        sql = "SELECT EM.*,ES.* FROM Emp_Master EM INNER JOIN Emp_Salary ES "\
                f"ON EM.Emp_Code = ES.Emp_Code  where ES.Current_Flag = 'Y' AND "\
                f"EM.Department_Code = '{request.data['Department_Code']}'"\
                f"OR EM.Designation_Code = '{request.data['Designation_Code']}'"
        data = dictfetchall(cnx.cursor().execute(sql))
        return Response(data=data, status=status.HTTP_200_OK)
    return Response(status=status.HTTP_501_NOT_IMPLEMENTED)




def get_loan_code():
    with cnx.cursor() as cursor:
        print('0I')
        res = dictfetchall(cursor.execute('SELECT COALESCE(MAX(SID)+1000001,1000000) as s_code FROM [Loan_Master];'))
        print(res[0]['s_code'])
    return 'LOC'+str(res[0]['s_code'])


@api_view(['GET','POST'])
def loan_module(request):
    if request.method == 'GET':
        return Response(data=dictfetchall(cnx.cursor().execute(f"SELECT EM.Emp_Code, EM.Emp_Name, EM.[Department_Code],"
                                                 f"EM.[Designation_Code], LM.[Loan_Code], LM.[Loan_Type],"
                                                 f"LM.[Loan_Amnt],LM.[FEA] "
                                                 f"FROM [Emp_Master] EM INNER JOIN [Loan_Master] LM "
                                                 f"ON EM.Emp_Code = LM.Emp_Code and LM.Active_Flag = 'Y'")), status=status.HTTP_200_OK)
    print(request.data)
    with cnx.cursor() as cursor:
        cursor.execute(
            f"INSERT INTO Loan_Master (Emp_Code, Loan_Amnt, Loan_Code, Loan_Type, FEA, Active_Flag, Insert_TS, Update_TS) "
            f"VALUES ('{request.data['Emp_Code']}', {request.data['Loan_Amnt']}, '{get_loan_code()}', '{request.data['Loan_Type']}', {request.data['FEA']},"
            f"'Y',getdate(),getdate())")
        return Response(status=status.HTTP_200_OK)


@xframe_options_exempt
def letter_settlement(request,pk):
    parm_list = pk.split(',')
    data = dictfetchall(cnx.cursor().execute(f"select ROW_NUMBER() OVER(ORDER BY (SELECT 1)) as RowNum, ET.[Emp_Name], EM.Account_No, ET.Net_Pay "
                                             f"FROM [Employee_Transaction] ET inner join [Emp_Master] EM on Em.Emp_Code = ET.Emp_Code "
                                             f"WHERE ET.Month = '{parm_list[0]}' and ET.Year = '{parm_list[1]}';"))
    total_amount = 0
    for item in data:
        total_amount += item['Net_Pay']
    return render(request, template_name='report_settlement.html', context={"data": data, 'tm': total_amount,'cn': parm_list[2]})



@api_view(['POST'])
def register_view(request):
    if request.method == 'POST':
        serializer = RegisterSerializer(data=request.data)
        if serializer.is_valid():
            dicti = validate_password(serializer.validated_data['password'])
            if dicti is not None:
                return Response(dicti, status=status.HTTP_412_PRECONDITION_FAILED)
            serializer.create(request.data)
            return Response(status=status.HTTP_200_OK)
    return Response(status=status.HTTP_501_NOT_IMPLEMENTED)


def validate_password(password):
    validators = [MinimumLengthValidator, UserAttributeSimilarityValidator, CommonPasswordValidator,
                  NumericPasswordValidator]
    try:
        for validator in validators:
            text = validator().get_help_text()
            validator().validate(password)
            return None
    except ValidationError as e:
        err_dict = {'msg': str(e), 'help_text': text}
        return err_dict


@api_view(['PUT'])
@permission_classes([IsAuthenticated])
def change_view(request, pk):
    print(request.user.id)
    try:
        user = User.objects.get(pk=pk)
    except User.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)
    if request.method == 'PUT':
        serializer = ChangeSerializer(user, data=request.data)
        if serializer.is_valid():
            verf_user = authenticate(username=request.data['username'], password=request.data['old_password'])
            if verf_user is not None:
                dicti = validate_password(request.data['password'])
                if dicti is not None:
                    return Response(dicti, status=status.HTTP_412_PRECONDITION_FAILED)
                user.set_password(request.data['password'])
                user.save()
                return Response({"msg": "Password Changed"}, status=status.HTTP_200_OK)
            else:
                return Response({"msg": "Please Provide correct username or password"},
                                status=status.HTTP_401_UNAUTHORIZED)
    return Response(status=status.HTTP_501_NOT_IMPLEMENTED)


def get_random_number(filename):
    try:
        with open(filename, 'r') as file:
            number = int(file.read())
    except FileNotFoundError:
        number = None
    return number


def set_random_number(filename, number):
    with open(filename, 'w') as file:
        file.write(str(number))


def update_random_number(filename):
    current_number = get_random_number(filename)
    if current_number is None:
        print("No previous random number found.")
        return
    new_number = random.randint(1, 100)  # Generate a new random number
    set_random_number(filename, new_number)
    print("Updated random number:", new_number)


# Usage example
filename = "random_number.txt"

# Get the current random number
current_random_number = get_random_number(filename)
if current_random_number is None:
    print("No random number found.")
else:
    print("Current random number:", current_random_number)


# Generate and store a new random number
new_random_number = random.randint(1, 100)  # Generate a new random number
set_random_number(filename, new_random_number)
print("New random number:", new_random_number)

# Update the random number
update_random_number(filename)

