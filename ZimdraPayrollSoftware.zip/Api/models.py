# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models

class DepartmentMaster(models.Model):
    sid = models.AutoField(db_column='SID', primary_key=True)  # Field name made lowercase.
    department_code = models.CharField(unique=True, db_column='Department_Code', max_length=10, blank=True,
                                       null=True)  # Field name made lowercase.
    department_desc = models.CharField(unique=True, db_column='Department_Desc', max_length=100, blank=True,
                                       null=True)  # Field name made lowercase.
    insert_ts = models.DateTimeField(db_column='Insert_TS', blank=True, null=True)  # Field name made lowercase.
    update_ts = models.DateTimeField(db_column='Update_TS', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'Department_Master'


class DesignationMaster(models.Model):
    sid = models.AutoField(db_column='SID', primary_key=True)  # Field name made lowercase.
    designation_code = models.CharField(unique=True, db_column='Designation_Code', max_length=10, blank=True,
                                        null=True)  # Field name made lowercase.
    designation_desc = models.CharField(unique=True, db_column='Designation_Desc', max_length=100, blank=True,
                                        null=True)  # Field name made lowercase.
    insert_ts = models.DateTimeField(db_column='Insert_TS', blank=True, null=True)  # Field name made lowercase.
    update_ts = models.DateTimeField(db_column='Update_TS', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'Designation_Master'


class EmpMaster(models.Model):
    sid = models.AutoField(db_column='SID', primary_key=True)  # Field name made lowercase.
    emp_code = models.CharField(unique=True, db_column='Emp_Code', max_length=20, blank=True,
                                null=True)  # Field name made lowercase.
    emp_name = models.CharField(db_column='Emp_Name', max_length=50, blank=True, null=True)  # Field name made lowercase.
    mobile_no = models.CharField(db_column='Mobile_No', max_length=13, blank=True, null=True)  # Field name made lowercase.
    email_id = models.CharField(db_column='Email_Id', max_length=200, blank=True, null=True)  # Field name made lowercase.
    emp_gender = models.CharField(db_column='Emp_Gender', max_length=20, blank=True, null=True)  # Field name made lowercase.
    address = models.CharField(db_column='Address', max_length=255, blank=True, null=True)  # Field name made lowercase.
    gov_id = models.CharField(db_column='Gov_Id', max_length=20, blank=True, null=True)  # Field name made lowercase.
    date_of_birth = models.DateField(db_column='Date_Of_Birth', blank=True, null=True)  # Field name made lowercase.
    date_of_join = models.DateField(db_column='Date_Of_Join', blank=True, null=True)  # Field name made lowercase.
    date_of_retirement = models.DateField(db_column='Date_Of_Retirement', blank=True, null=True)  # Field name made lowercase.
    date_of_resignation = models.DateField(db_column='Date_Of_Resignation', blank=True, null=True)  # Field name made lowercase.
    tpn_no = models.CharField(db_column='TPN_No', max_length=20, blank=True, null=True)  # Field name made lowercase.
    account_no = models.CharField(db_column='Account_No', max_length=20, blank=True, null=True)  # Field name made lowercase.
    pf_no = models.CharField(db_column='Pf_No', max_length=20, blank=True, null=True)  # Field name made lowercase.
    insurance_no = models.CharField(db_column='Insurance_No', max_length=20, blank=True, null=True)  # Field name made lowercase.
    gis_account_no = models.CharField(db_column='GIS_Account_No', max_length=20, blank=True, null=True)  # Field name made lowercase.
    designation_code = models.CharField(db_column='Designation_Code', max_length=100, blank=True, null=True)  # Field name made lowercase.
    department_code = models.CharField(db_column='Department_Code', max_length=100, blank=True, null=True)  # Field name made lowercase.
    employee_type_flag = models.CharField(db_column='Employee_Type_Flag', max_length=1, blank=True, null=True)  # Field name made lowercase.
    active_flag = models.CharField(db_column='Active_Flag', max_length=1, blank=True, null=True)  # Field name made lowercase.
    insert_ts = models.DateTimeField(db_column='Insert_TS', blank=True, null=True)  # Field name made lowercase.
    update_ts = models.DateTimeField(db_column='Update_TS', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'Emp_Master'


class Attendence(models.Model):
    sid = models.AutoField(db_column='SID', primary_key=True)  # Field name made lowercase.
    emp_code = models.CharField(db_column='Emp_Code', max_length=20, blank=True, null=True)  # Field name made lowercase.
    cal_month = models.CharField(db_column='Cal_Month', max_length=10, blank=True, null=True)  # Field name made lowercase.
    cal_year = models.CharField(db_column='Cal_Year', max_length=5, blank=True, null=True)  # Field name made lowercase.
    total_month_day = models.IntegerField(db_column='Total_Month_Day', blank=True, null=True)  # Field name made lowercase.
    total_working_day = models.IntegerField(db_column='Total_Working_Day', blank=True, null=True)  # Field name made lowercase.
    avail_pl = models.DecimalField(db_column='Avail_PL', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    avail_cl = models.DecimalField(db_column='Avail_CL', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    avail_sl = models.DecimalField(db_column='Avail_SL', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    avail_lwop = models.DecimalField(db_column='Avail_LWOP', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    avail_ml = models.DecimalField(db_column='Avail_ML', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    avail_el = models.DecimalField(db_column='Avail_EL', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    avail_bl = models.DecimalField(db_column='Avail_BL', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    total_avail_leave = models.DecimalField(db_column='Total_Avail_Leave', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    overtime = models.DecimalField(db_column='Overtime', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    insert_ts = models.DateTimeField(db_column='Insert_TS', blank=True, null=True)  # Field name made lowercase.
    update_ts = models.DateTimeField(db_column='Update_TS', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'Attendence'


class EmpSalary(models.Model):
    sid = models.AutoField(db_column='SID', primary_key=True)  # Field name made lowercase.
    emp_code = models.CharField(db_column='Emp_Code', max_length=20, blank=True,
                                null=True)  # Field name made lowercase.  # Field name made lowercase.
    basic_pay = models.DecimalField(db_column='Basic_Pay', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    da = models.DecimalField(db_column='DA', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    hra = models.DecimalField(db_column='HRA', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    tds = models.DecimalField(db_column='TDS', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    pf_amnt = models.DecimalField(db_column='PF_Amnt', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    gis_amnt = models.DecimalField(db_column='GIS_Amnt', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    current_flag = models.CharField(db_column='Current_Flag', max_length=1, blank=True, null=True)  # Field name made lowercase.
    lpa = models.DecimalField(db_column='LPA', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    fy_year = models.CharField(db_column='FY_Year', max_length=10, blank=True, null=True)  # Field name made lowercase.
    insert_ts = models.DateTimeField(db_column='Insert_TS', blank=True, null=True)  # Field name made lowercase.
    update_ts = models.DateTimeField(db_column='Update_TS', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'Emp_Salary'


class EmpSpecialAllowanceDeduction(models.Model):
    sid = models.AutoField(db_column='SID', primary_key=True)  # Field name made lowercase.
    emp_code = models.CharField(db_column='Emp_Code', max_length=20, blank=True,
                                null=True)  # Field name made lowercase.  # Field name made lowercase.
    cmonth = models.CharField(db_column='CMONTH', max_length=20, blank=True, null=True)  # Field name made lowercase.
    cyear = models.CharField(db_column='CYear', max_length=4, blank=True, null=True)  # Field name made lowercase.
    conv_allow = models.DecimalField(db_column='Conv_Allow', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    vouc_allow = models.DecimalField(db_column='Vouc_Allow', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    special_allow = models.DecimalField(db_column='Special_Allow', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    le_allow = models.DecimalField(db_column='LE_Allow', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    ltc_allow = models.DecimalField(db_column='LTC_Allow', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    ot_allow = models.DecimalField(db_column='OT_Allow', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    bonus_allow = models.DecimalField(db_column='Bonus_Allow', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    other_allow = models.DecimalField(db_column='Other_Allow', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    benifit_allow = models.DecimalField(db_column='Benifit_Allow', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    arr_allow = models.DecimalField(db_column='Arr_Allow', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    advance_ded = models.DecimalField(db_column='Advance_Ded', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    special_ded = models.DecimalField(db_column='Special_Ded', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    loan_skip_flag = models.CharField(db_column='Loan_Skip_Flag', max_length=1, blank=True, null=True)  # Field name made lowercase.
    insert_ts = models.DateTimeField(db_column='Insert_TS', blank=True, null=True)  # Field name made lowercase.
    update_ts = models.DateTimeField(db_column='Update_TS', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'Emp_Special_Allowance_Deduction'


class EmployeeTransaction(models.Model):
    sid = models.AutoField(db_column='SID', primary_key=True)  # Field name made lowercase.
    year = models.CharField(db_column='Year', max_length=4)  # Field name made lowercase.
    month = models.CharField(db_column='Month', max_length=20)  # Field name made lowercase.
    emp_code = models.CharField(db_column='Emp_Code', max_length=20, blank=True,
                                null=True)   # Field name made lowercase.
    emp_name = models.CharField(db_column='Emp_Name', max_length=50, blank=True, null=True)  # Field name made lowercase.
    tpn_no = models.CharField(db_column='TPN_No', max_length=20, blank=True, null=True)  # Field name made lowercase.
    designation_desc = models.CharField(db_column='Designation_Desc', max_length=100, blank=True, null=True)  # Field name made lowercase.
    department_desc = models.CharField(db_column='Department_Desc', max_length=100, blank=True, null=True)  # Field name made lowercase.
    basic_pay = models.DecimalField(db_column='Basic_Pay', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    hra = models.DecimalField(db_column='HRA', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    special_allowance = models.DecimalField(db_column='Special_Allowance', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    conv_allow = models.DecimalField(db_column='Conv_Allow', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    vouc_allow = models.DecimalField(db_column='Vouc_Allow', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    leave_encashment = models.DecimalField(db_column='Leave_Encashment', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    travel_concession = models.DecimalField(db_column='Travel_Concession', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    overtime = models.DecimalField(db_column='Overtime', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    bonus = models.DecimalField(db_column='Bonus', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    gross_pay = models.DecimalField(db_column='Gross_Pay', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    pf_amnt = models.DecimalField(db_column='PF_Amnt', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    tds_amnt = models.DecimalField(db_column='TDS_Amnt', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    hc_amnt = models.DecimalField(db_column='HC_Amnt', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    gis_amnt = models.DecimalField(db_column='GIS_Amnt', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    salary_advance = models.DecimalField(db_column='Salary_Advance', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    loan = models.DecimalField(db_column='Loan', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    special_deduction = models.DecimalField(db_column='Special_Deduction', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    other = models.DecimalField(db_column='Other', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    net_pay = models.DecimalField(db_column='Net_Pay', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    flag = models.CharField(db_column='Flag', max_length=1, blank=True, null=True)  # Field name made lowercase.
    insert_ts = models.DateTimeField(db_column='Insert_TS', blank=True, null=True)  # Field name made lowercase.
    update_ts = models.DateTimeField(db_column='Update_TS', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'Employee_Transaction'


class LeaveMaster(models.Model):
    sid = models.AutoField(db_column='SID', primary_key=True)  # Field name made lowercase.
    emp_code = models.CharField(db_column='Emp_Code', max_length=20, blank=True,
                                null=True)  # Field name made lowercase.  # Field name made lowercase.
    avl_pl = models.DecimalField(db_column='Avl_PL', max_digits=10, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    avl_cl = models.DecimalField(db_column='Avl_CL', max_digits=10, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    avl_sl = models.DecimalField(db_column='Avl_SL', max_digits=10, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    op_pl = models.DecimalField(db_column='OP_PL', max_digits=10, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    op_cl = models.DecimalField(db_column='OP_CL', max_digits=10, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    op_sl = models.DecimalField(db_column='OP_SL', max_digits=10, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    insert_ts = models.DateTimeField(db_column='Insert_TS', blank=True, null=True)  # Field name made lowercase.
    update_ts = models.DateTimeField(db_column='Update_TS', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'Leave_Master'


class LoanMaster(models.Model):
    sid = models.AutoField(db_column='SID', primary_key=True)  # Field name made lowercase.
    emp_code = models.CharField(db_column='Emp_Code', max_length=20, blank=True,
                                null=True)  # Field name made lowercase.  # Field name made lowercase.
    loan_amnt = models.DecimalField(db_column='Loan_Amnt', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    loan_code = models.CharField(db_column='Loan_Code', max_length=10, blank=True, null=True)  # Field name made lowercase.
    loan_type = models.CharField(db_column='Loan_Type', max_length=10, blank=True, null=True)  # Field name made lowercase.
    fea = models.DecimalField(db_column='FEA', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    no_ins = models.IntegerField(db_column='No_Ins', blank=True, null=True)  # Field name made lowercase.
    active_flag = models.CharField(db_column='Active_Flag', max_length=1, blank=True, null=True)  # Field name made lowercase.
    insert_ts = models.DateTimeField(db_column='Insert_TS', blank=True, null=True)  # Field name made lowercase.
    update_ts = models.DateTimeField(db_column='Update_TS', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'Loan_Master'


class LoanTransaction(models.Model):
    sid = models.AutoField(db_column='SID', primary_key=True)  # Field name made lowercase.
    emp_code = models.CharField(db_column='Emp_Code', max_length=20, blank=True,
                                null=True)  # Field name made lowercase.  # Field name made lowercase.
    loan_code = models.CharField(db_column='Loan_Code', max_length=10, blank=True, null=True)  # Field name made lowercase.
    emi_month = models.CharField(db_column='Emi_Month', max_length=20, blank=True, null=True)  # Field name made lowercase.
    emi_year = models.CharField(db_column='Emi_Year', max_length=4, blank=True, null=True)  # Field name made lowercase.
    emi_amnt = models.DecimalField(db_column='EMI_Amnt', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    insert_ts = models.DateTimeField(db_column='Insert_TS', blank=True, null=True)  # Field name made lowercase.
    update_ts = models.DateTimeField(db_column='Update_TS', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'Loan_Transaction'


class TaxMaster(models.Model):
    sid = models.AutoField(db_column='SID', primary_key=True)  # Field name made lowercase.
    lower_limit = models.DecimalField(db_column='Lower_Limit', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    upper_limit = models.DecimalField(db_column='Upper_Limit', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    tax_perc = models.DecimalField(db_column='Tax_Perc', max_digits=10, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    insert_ts = models.DateTimeField(db_column='Insert_TS', blank=True, null=True)  # Field name made lowercase.
    update_ts = models.DateTimeField(db_column='Update_TS', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'Tax_Master'


class AuthGroup(models.Model):
    name = models.CharField(unique=True, max_length=150)

    class Meta:
        managed = False
        db_table = 'auth_group'


class AuthGroupPermissions(models.Model):
    id = models.BigAutoField(primary_key=True)
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)
    permission = models.ForeignKey('AuthPermission', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_group_permissions'
        unique_together = (('group', 'permission'),)


class AuthPermission(models.Model):
    name = models.CharField(max_length=255)
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING)
    codename = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'auth_permission'
        unique_together = (('content_type', 'codename'),)


class AuthUser(models.Model):
    password = models.CharField(max_length=128)
    last_login = models.DateTimeField(blank=True, null=True)
    is_superuser = models.BooleanField()
    username = models.CharField(unique=True, max_length=150)
    first_name = models.CharField(max_length=150)
    last_name = models.CharField(max_length=150)
    email = models.CharField(max_length=254)
    is_staff = models.BooleanField()
    is_active = models.BooleanField()
    date_joined = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'auth_user'


class AuthUserUserPermissions(models.Model):
    id = models.BigAutoField(primary_key=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    permission = models.ForeignKey(AuthPermission, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_user_permissions'
        unique_together = (('user', 'permission'),)


class DjangoAdminLog(models.Model):
    action_time = models.DateTimeField()
    object_id = models.TextField(blank=True, null=True)
    object_repr = models.CharField(max_length=200)
    action_flag = models.SmallIntegerField()
    change_message = models.TextField()
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING, blank=True, null=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'django_admin_log'


class DjangoContentType(models.Model):
    app_label = models.CharField(max_length=100)
    model = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'django_content_type'
        unique_together = (('app_label', 'model'),)


class DjangoMigrations(models.Model):
    id = models.BigAutoField(primary_key=True)
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class DjangoSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=40)
    session_data = models.TextField()
    expire_date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_session'


class DataChecking(models.Model):
    sid = models.AutoField(db_column='SID', primary_key=True)  # Field name made lowercase.
    year = models.CharField(db_column='Year', max_length=4, blank=True, null=True)  # Field name made lowercase.
    month = models.CharField(db_column='Month', max_length=20, blank=True, null=True)  # Field name made lowercase.
    attendance = models.CharField(db_column='Attendance', max_length=1, blank=True, null=True)  # Field name made lowercase.
    emp_sad = models.CharField(db_column='Emp_SAD', max_length=1, blank=True, null=True)  # Field name made lowercase.
    loan_master = models.CharField(db_column='Loan_Master', max_length=1, blank=True, null=True)  # Field name made lowercase.
    insert_ts = models.DateTimeField(db_column='Insert_TS', blank=True, null=True)  # Field name made lowercase.
    update_ts = models.DateTimeField(db_column='Update_TS', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'Data_Checking'


class AuthModel(models.Model):
    sid = models.AutoField(primary_key=True)
    username = models.CharField(db_column='UNAME', max_length=4, blank=True, null=True)
    password = models.CharField(db_column='PWD', max_length=256, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'Auth_Model'

    def __str__(self):
        return f"Username : {self.username}"



class ExceptionTable(models.Model):
    sid = models.AutoField(db_column='SID', primary_key=True)  # Field name made lowercase.
    errornumber = models.IntegerField(db_column='ErrorNumber', blank=True, null=True)  # Field name made lowercase.
    errorseverity = models.IntegerField(db_column='ErrorSeverity', blank=True, null=True)  # Field name made lowercase.
    errorstate = models.IntegerField(db_column='ErrorState', blank=True, null=True)  # Field name made lowercase.
    errorprocedure = models.CharField(db_column='ErrorProcedure', max_length=100, blank=True, null=True)  # Field name made lowercase.
    errorline = models.IntegerField(db_column='ErrorLine', blank=True, null=True)  # Field name made lowercase.
    errormessage = models.CharField(db_column='ErrorMessage', max_length=255, blank=True, null=True)  # Field name made lowercase.
    insert_ts = models.DateTimeField(db_column='Insert_TS', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = True
        db_table = 'Exception_Table'









