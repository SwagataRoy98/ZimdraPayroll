from django.db.models import Count
from rest_framework.serializers import ModelSerializer, Serializer
from rest_framework import serializers
from .models import EmpSalary, EmpMaster, EmpSpecialAllowanceDeduction, EmployeeTransaction, TaxMaster, LeaveMaster, \
    Attendence, DepartmentMaster, DesignationMaster
from django.contrib.auth.models import User


#employees_per_department = EmpMaster.objects.values('department_code__department_desc').annotate(num_employees=Count('sid'))
#department_code__in=DepartmentMaster.objects.filter(department_code='EE')

class DesignationMasterSerializer(ModelSerializer):
    class Meta:
        model = DesignationMaster
        fields = ['designation_code', 'designation_desc', 'insert_ts', 'update_ts']


class AttendanceSerializer(ModelSerializer):
    class Meta:
        model = Attendence
        fields = '__all__'



class EmployeeMasterSerializer(ModelSerializer):
    class Meta:
        model = EmpMaster
        fields = '__all__'


class EmployeeCustomerSerializer(serializers.Serializer):
    emp_code__emp_code = serializers.CharField()
    emp_code__emp_name = serializers.CharField()
    emp_code__mobile_no = serializers.CharField()
    emp_code__email_id = serializers.EmailField()
    emp_code__gov_id = serializers.CharField()
    emp_code__date_of_birth = serializers.DateField()
    emp_code__date_of_join = serializers.DateField()
    emp_code__date_of_retirement = serializers.DateField(required=False, allow_null=True)
    emp_code__date_of_resignation = serializers.DateField(required=False, allow_null=True)
    emp_code__tpn_no = serializers.CharField(required=False, allow_null=True)
    emp_code__account_no = serializers.CharField(required=False, allow_null=True)
    emp_code__pf_no = serializers.CharField(required=False, allow_null=True)
    emp_code__insurance_no = serializers.CharField(required=False, allow_null=True)
    emp_code__gis_account_no = serializers.CharField(required=False, allow_null=True)
    emp_code__designation_code = serializers.CharField()
    emp_code__department_code = serializers.CharField()
    emp_code__employee_type_flag = serializers.BooleanField()
    basic_pay = serializers.DecimalField(max_digits=10, decimal_places=2)
    da = serializers.DecimalField(max_digits=10, decimal_places=2)
    hra = serializers.DecimalField(max_digits=10, decimal_places=2)
    pf_amnt = serializers.DecimalField(max_digits=10, decimal_places=2)
    gis_amnt = serializers.DecimalField(max_digits=10, decimal_places=2)
    current_flag = serializers.BooleanField()


class EDMS(ModelSerializer):
    class Meta:
        model = EmpMaster
        fields = ['emp_code', 'emp_name', 'mobile_no', 'email_id', 'gov_id', 'date_of_birth', 'date_of_join',
                  'date_of_retirement', 'date_of_resignation', 'tpn_no', 'account_no', 'pf_no', 'insurance_no',
                  'gis_account_no', 'designation_code', 'department_code', 'employee_type_flag']


class EmployeeViewSerializer(ModelSerializer):
    emp_master = EDMS(many=True)
    class Meta:
        model = EmpSalary
        fields = ['emp_master', 'basic_pay', 'da', 'hra', 'pf_amnt',
                  'gis_amnt', 'current_flag']


class DepartmentMasterSerializer(ModelSerializer):

    class Meta:
        model = DepartmentMaster
        fields = ['department_code', 'department_desc', 'insert_ts', 'update_ts']


class DepartmentCustomSerializer(Serializer):
    department_code = serializers.CharField()
    department_desc = serializers.CharField()
    insert_ts = serializers.DateTimeField()
    update_ts = serializers.DateTimeField()


class DesignationCustomSerializer(Serializer):
    designation_code = serializers.CharField()
    designation_desc = serializers.CharField()
    insert_ts = serializers.DateTimeField()
    update_ts = serializers.DateTimeField()


class TaxMasterSerializer(ModelSerializer):
    class Meta:
        model = TaxMaster
        fields = ['lower_limit', 'upper_limit', 'tax_perc']


class EmpSADSerializer(ModelSerializer):
    class Meta:
        model = EmpSpecialAllowanceDeduction
        fields = ['sid', 'emp_code', 'entry_date', 'a_d_type', 'a_d_desc',
                  'a_d_amnt']


class RegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'email', 'password']

    def create(self, validated_data):
        password = validated_data.pop('password', None)
        instance = self.Meta.model(**validated_data)
        instance.is_active = True
        if password is not None:
            instance.set_password(password)
        instance.save()
        return instance


class ChangeSerializer(serializers.ModelSerializer):
    old_password = serializers.CharField(
        write_only=True,
        required=True
    )

    class Meta:
        model = User
        fields = ['username', 'old_password','password']





