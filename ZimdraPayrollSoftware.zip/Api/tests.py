from django.test import TestCase

# Create your tests here.
class Encryptor:

    def __int__(self):
        self.counter = 0
        self.mob_no = 9836069535


    def enc_func(self):
        return f"{self.counter} - {self.mob_no}"

    def set_enc_no(self):
        counter = self.counter + 1